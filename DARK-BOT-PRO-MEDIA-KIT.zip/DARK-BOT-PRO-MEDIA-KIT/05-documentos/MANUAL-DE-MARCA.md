# DARK BOT — direção de marca editorial

## Essência
**DARK BOT é controlo que não pesa.** A comunicação deve fazer o produto parecer organizado, sério e actual — nunca um amontoado de comandos, efeitos neon genéricos ou promessas de “tudo automático”.

## Assinatura visual
- **Fundo:** carbono `#0A0B0C`
- **Superfície:** grafite `#111214`
- **Texto:** osso `#F4F3EE`
- **Sinal principal:** lime eléctrico `#C7FF00`
- **Sinal secundário:** violeta `#7C5CFF`
- **Sistema:** wordmark `DARK / BOT`, quadrado-lime, grelha discreta, linhas técnicas e numeração editorial.

## Tipografia
- Título: **Space Grotesk Bold** em maiúsculas; poucas linhas, leitura imediata.
- Texto: Space Grotesk Regular/Medium; frases curtas e concretas.
- Não misturar muitas fontes, sombras, emojis no título, gradientes coloridos ou parágrafos longos dentro da arte.

## Composição
1. Uma ideia por peça.
2. Headline grande com alto contraste.
3. Espaço vazio intencional; o conteúdo não deve ocupar tudo.
4. Um único CTA por post.
5. Uma foto/objeto editorial ou um módulo gráfico — não ambos competindo.

## Voz
- Directa, clara, adulta e útil.
- Diz o benefício antes da funcionalidade.
- Exemplo: “O admin define o limite.” antes de listar “anti-link e anti-spam”.
- Evitar: “o melhor bot”, “100% protegido”, “nunca falha”, “IA faz tudo”.
