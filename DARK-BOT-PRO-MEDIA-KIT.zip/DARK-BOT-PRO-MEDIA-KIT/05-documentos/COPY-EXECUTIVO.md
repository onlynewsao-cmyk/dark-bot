# Copy pronta — campanha editorial DARK BOT

Substitui `[LINK DO WHATSAPP]` e `[LINK DA LANDING]` antes de publicar.

## Post feed 01 — manifesto
> Um grupo não precisa virar trabalho infinito para o admin.
>
> O DARK BOT ajuda a organizar a rotina com regras, proteções configuráveis, boas-vindas, ferramentas de comunidade e controlo num só lugar.
>
> Começa pelo essencial. Testa no teu próprio grupo por 7 dias.
>
> `[LINK DO WHATSAPP]`
>
> #WhatsApp #Comunidade #AdminDeGrupo #Automação

## Post feed 02 — admin
> Quem gere uma comunidade sabe: o difícil não é só fazer o grupo crescer. É manter a experiência boa quando ele já cresceu.
>
> O DARK BOT foi pensado para dar estrutura à rotina do admin — sem tirar o controlo de quem conhece a própria comunidade.
>
> Fala connosco sobre o trial: `[LINK DO WHATSAPP]`

## Post feed 03 — mídia
> Quando a comunidade pede uma música, vídeo ou conteúdo, a experiência não precisa sair do chat.
>
> O DARK BOT tem ferramentas de mídia para fontes suportadas, além de figurinhas, texto animado, jogos e recursos de comunidade.
>
> Usa sempre conteúdo público ou autorizado. A disponibilidade pode variar por plataforma.
>
> Trial: `[LINK DO WHATSAPP]`

## Post feed 04 — comunidade
> O melhor grupo não é o que envia mais mensagens. É o que dá razões para as pessoas voltarem.
>
> Jogos, rankings, RPG, interações, mídia e ferramentas opcionais ajudam a construir essa experiência — sempre com a configuração certa para o teu objetivo.
>
> Conhece o DARK BOT: `[LINK DA LANDING]`

## Legenda para o carrossel
> Não é sobre colocar tudo no grupo. É sobre colocar o que o grupo precisa.
>
> Desliza para ver como o DARK BOT organiza, protege e ativa a experiência de uma comunidade no WhatsApp.
>
> ✦ Trial de 7 dias. Configuração essencial orientada. Sem promessas vazias.
>
> `[LINK DO WHATSAPP]`

## Sequência para WhatsApp Status / Stories
1. “O grupo cresceu. O trabalho do admin também.”
2. “A diferença está no sistema que apoia a rotina: regras, proteções e recursos configuráveis.”
3. “Testa no teu próprio grupo por 7 dias. Responde **TRIAL**.”

## Descrição do Reel / YouTube Short
> O DARK BOT ajuda grupos, negócios e comunidades a trabalhar com mais organização, proteção e experiência no WhatsApp.
>
> Trial de 7 dias: `[LINK DO WHATSAPP]`
>
> Recursos de mídia dependem das plataformas suportadas. Usa conteúdo público ou autorizado.

## Resposta a alguém que pediu informação
> Perfeito. Para indicar uma configuração que faça sentido, diz-me só:
> 1. É grupo, negócio ou comunidade?
> 2. O que hoje dá mais trabalho: organização, moderação, conteúdo ou participação?
> 3. Quantas pessoas participam mais ou menos?
>
> Depois explico como funciona o trial de 7 dias e o que podemos configurar primeiro.
