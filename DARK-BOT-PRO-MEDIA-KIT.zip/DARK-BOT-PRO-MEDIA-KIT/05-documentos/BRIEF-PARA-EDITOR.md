# Brief para editor / social media

## Objectivo
Gerar conversas voluntárias para trial de 7 dias. A campanha deve parecer um produto digital sério e actual — não uma página de “comandos infinitos”.

## Entregáveis já prontos
- 4 feed posts (1080×1350)
- 5 slides de carrossel (1080×1080)
- 3 Stories/Status (1080×1920)
- 1 thumbnail YouTube (1280×720)
- 1 Reel silencioso (720×1280, 16 s)
- Copy aprovada e guia de marca

## Cadência mínima
- 2 posts de feed por semana
- 1 carrossel por semana
- 2 sequências de Stories/Status por semana
- 1 Reel/Short por semana

## Publicação
1. Substituir os links nos textos.
2. Confirmar que alguém vai responder a “TRIAL”.
3. Publicar em canais próprios, anúncios segmentados ou conversas que a pessoa iniciou.
4. Medir: guardados, partilhas, respostas, cliques, conversas e trials; não só likes.

## Segurança
O editor NÃO recebe senha de Dashboard, QR/sessão WhatsApp, tokens, listas de clientes, pagamentos nem dados pessoais. Para uma demo, criar grupo e contactos fictícios/autorizados.

## Não publicar/prometer
- “Posta automaticamente no YouTube/Facebook/Instagram/TikTok.”
- “Proteção 100%” ou disponibilidade garantida de qualquer link.
- IA incluída sem confirmar que o provider está configurado.
- Prints com dados de clientes ou de grupos reais.
