# Comparação de design — do kit anterior ao padrão profissional actual

## Diagnóstico honesto do kit anterior

| Critério | Kit anterior | Problema | Nova direcção |
|---|---|---|---|
| Identidade | Roxo/azul e ícones genéricos de tecnologia | Parecia um template de “bot/IA”, não uma marca própria | Sistema carbono + lime + violeta, assinatura `DARK / BOT`, grelha e numeração repetíveis |
| Hierarquia | Vários bullets e mensagens no mesmo layout | A pessoa precisa ler demais antes de entender | Uma promessa grande, uma prova curta e um CTA por peça |
| Imagem | Mockups e UI genéricos com muitos elementos | “Bonito”, mas pouco distintivo | Fotografia editorial e objeto escultórico, usados com espaço vazio e contraste |
| Tipografia | Peso/escala mais comum e visual de flyer | Menos autoridade em feed profissional | Space Grotesk, títulos compactos e composição inspirada em editorial/SaaS |
| Conversão | CTAs parecidos em todas as artes | Não guia uma sequência de descoberta | Feed = benefício; carrossel = explicação; Stories = resposta; Reel = descoberta |
| Vídeo | Mais próximo de slideshow informativo | Pouca cadência de campanha | Reel editorial curto, com cortes, zoom subtil, texto legível e sequência narrativa |

## O que foi aplicado no novo kit

- **Sistema, não peças isoladas:** a marca reconhece-se pelo quadrado-lime, wordmark, grelha, linha de sinal e numeração.
- **Restrição intencional:** duas cores de acento, uma família tipográfica e um CTA por peça. Isto aumenta reconhecimento e evita a estética de template.
- **Mensagem primeiro:** cada post responde rapidamente a uma pergunta: “porquê?”, “para quem?”, “o que muda?” ou “qual é o próximo passo?”.
- **Imagens com função:** a fotografia humana representa quem administra; o objeto tecnológico representa o produto. Não são decoração.
- **Benefícios reais:** organização, proteções configuráveis, mídia, comunidade, Dashboard e trial. Não anuncia publicação automática em redes sociais externas.

## Referência de padrão, sem copiar marcas

A avaliação tomou como referência princípios que equipas profissionais de SaaS usam: identidade consistente em todos os pontos de contacto, tipografia legível, alto contraste, espaço em branco, linguagem clara e demonstração de valor em vez de listas intermináveis.

Leituras de benchmark:
- Superside — consistência de sistemas de marca e exemplos de SaaS: https://www.superside.com/blog/graphic-design-for-saas
- TodayMade — clareza, contraste e espaço para anúncios tipográficos de SaaS: https://www.todaymade.com/blog/typography-ads
- Arounda — identidade de SaaS, tipografia e coerência entre canais: https://arounda.agency/blog/branding-examples

Estas referências são **critérios de qualidade**, não modelos copiados. As artes do pacote são originais.

## O que ainda separa uma campanha “boa” de uma campanha de agência completa

1. **Demonstração real do produto:** o próximo passo é gravar 1–2 minutos de um grupo de demonstração e Dashboard de demonstração, sem dados privados. É a melhor prova possível.
2. **Teste de performance:** testar dois hooks, medir retenção do Reel, respostas a Stories e conversas iniciadas; não escolher criativos só pelo gosto visual.
3. **Motion e som licenciados:** para anúncios, acrescentar locução humana e áudio licenciado dentro da plataforma. O Reel entregue é silencioso para manter segurança de licença.
4. **Banco de fotos próprio:** quando houver orçamento, fotografar o Dono/equipa ou usar sessão licenciada. Isso cria uma assinatura ainda mais difícil de copiar.

## Decisão recomendada

Usar este kit como padrão de lançamento agora. Em paralelo, gravar uma demo real autorizada e substituir os mockups conceptuais por momentos reais do produto nos próximos conteúdos.
