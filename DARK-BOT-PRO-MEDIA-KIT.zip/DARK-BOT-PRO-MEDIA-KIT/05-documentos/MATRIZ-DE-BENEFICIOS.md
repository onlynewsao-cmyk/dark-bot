# Benefícios do DARK BOT — guia de mensagem

## Para o admin

| Benefício | Como explicar | Base funcional real |
|---|---|---|
| Menos tarefas repetitivas | O admin deixa de executar sempre as mesmas rotinas manualmente. | Menus, comandos, regras, avisos e ferramentas de grupo. |
| Mais controlo | O dono/admin escolhe o que fica ligado e como o grupo funciona. | Gestão de grupo, links, permissões, configurações e Dashboard. |
| Ambiente mais organizado | A comunidade recebe uma estrutura que pode acompanhar o seu ritmo. | Anti-link, anti-spam, anti-flood e outras proteções configuráveis. |
| Entrada mais profissional | Quem entra entende melhor onde chegou. | Boas-vindas, despedidas e modos visuais de welcome. |
| Gestão com visibilidade | A operação deixa de ficar escondida em mensagens soltas. | Dashboard protegido para configurações, grupos, planos e estado do serviço. |

## Para criadores e comunidades

| Benefício | Como explicar | Base funcional real |
|---|---|---|
| Mais participação | O grupo ganha motivos concretos para as pessoas voltarem. | Jogos, quiz, rankings, economia, interações e recursos de RPG opcionais. |
| Linguagem própria | A comunidade pode criar conteúdo que combina com o seu estilo. | Figurinhas, texto animado, ferramentas visuais e cartões. |
| Conteúdo mais acessível no chat | Certas necessidades de mídia deixam de exigir sair do fluxo da conversa. | Opções de áudio/vídeo YouTube e ferramentas para links suportados. |
| Experiência configurável | O grupo não precisa parecer outro grupo. | Temas, mensagens, módulos e recursos escolhidos conforme o objetivo. |

## Para negócios e donos

| Benefício | Como explicar | Base funcional real |
|---|---|---|
| Arranque guiado | A pessoa não recebe apenas uma lista de comandos. | Trial de 7 dias, configuração essencial e instalação personalizada. |
| Operação em camadas | A configuração acompanha a maturidade do projeto. | Planos, permissões, Dashboard e módulos opcionais. |
| IA como apoio | A IA pode ajudar no fluxo, sem substituir decisão e permissões humanas. | Conversa, memória, pesquisa e imagem quando os providers estiverem configurados. |
| Comunicação de campanha mais clara | O interesse chega por canais próprios e é qualificado antes do trial. | Landing pública, CTA WhatsApp e kit interno de marketing. |

## Informação obrigatória para comunicar com honestidade

- O bot opera no **WhatsApp**. O material pode ser publicado em YouTube, Facebook, Instagram e TikTok, mas o bot não publica automaticamente nessas contas externas.
- Recursos de links/mídia dependem da disponibilidade das plataformas. Comunicar sempre “conteúdo público ou autorizado”.
- IA só deve ser anunciada como disponível quando o provider necessário estiver configurado.
- A foto de perfil pode ser incorporada em certos visuais somente quando o WhatsApp a disponibiliza; não é reconhecimento facial nem recriação da pessoa por IA.
- Proteções são configuráveis e complementam a moderação humana; não prometer “segurança total”.
